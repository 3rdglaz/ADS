
/**
 * Write a description of class Carro here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Carro
{
    private boolean ar, cambioAutomatico,alarme,pinturaEspecial,tetoSolar,multimidia, umPonto0,importado;
    private double preco;
    
    /**
     * Constructor for objects of class Carro
     */
    public Carro()
    {
        
        
    }
    public void setAr(boolean ar){this.ar=ar;}
    public void setCambioAutomatico(boolean cambioAutomatico){this.cambioAutomatico=cambioAutomatico;}
    public void setAlarme(boolean alarme){this.alarme=alarme;}
    public void setPinturaEspecial(boolean pinturaEspecial){this.pinturaEspecial=pinturaEspecial;}
    public void setTetoSolar(boolean tetoSolar){this.tetoSolar=tetoSolar;}
    public void setMultimidia(boolean multimidia){this.multimidia=multimidia;}
    public void setUmPonto0(boolean umPonto0){this.umPonto0=umPonto0;}
    public void setImportado(boolean importado){this.importado=importado;}
    public double custoFinal()
    {
        //preco = Math.round(Math.random()*1000);
        preco = 100;
        double ipi = 1.2;
        if(umPonto0){
            ipi = 1.1;
        }
        
        if(ar)
            preco += 3000;
        if(cambioAutomatico)
            preco+= 5000;
        if(alarme)
            preco+=800;
        if(pinturaEspecial)
            preco+=2500;
        if(tetoSolar)
            preco+=4000;
        if(multimidia)
            preco+=1800;
        preco *=ipi;
        if(importado){
            preco *= 1.3;
        }
        return preco;
    }
    public String contem()
    {
        //preco = Math.round(Math.random()*1000);
        String contem = "Contem: ";
        
        if(umPonto0){
            contem+= "\n 1.0";
        }
        if(ar)
            contem+= "\n Ar Condicionado";
        if(cambioAutomatico)
            contem+= "\n Cambio Automatico";
        if(alarme)
            contem+= "\n Alarme";
        if(pinturaEspecial)
            contem+= "\n Pintura";
        if(tetoSolar)
            contem+= "\n Teto Solar";
        if(multimidia)
            contem+= "\n Kit Multimidia";
        if(importado){
            contem+= "\n Importado";
        }
        return contem;
    }
}
