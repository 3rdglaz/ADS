
public class Professor
{

    private double salario;
    private int aulasDadas;
    

    
    public Professor()
    {
    
    
    }

        public int sampleMethod(int y)
    {
        return 0;
    }
}
