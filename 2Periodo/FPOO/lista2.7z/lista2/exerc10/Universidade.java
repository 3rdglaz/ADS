
public class Universidade
{
    // instance variables - replace the example below with your own
    private String nome;

    public Universidade()
    {
    
    }
    public String getNome(){return nome;}
    public void setNome(String nome){this.nome=nome;}
    
    
}
