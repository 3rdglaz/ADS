public class Imovel
{
    // instance variables - replace the example below with your own
    private String endereco;
    private double preco;

    public Imovel()
    {

    }
    public int sampleMethod(int y)
    {
        return 0;
    }
    
    public double getPreco(){return preco;}
    public void setPreco(double preco){this.preco=preco;}
    public String getEndereco(){return endereco;}
    public void setEndereco(String endereco){this.endereco=endereco;}
}
