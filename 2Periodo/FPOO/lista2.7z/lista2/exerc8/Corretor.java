import java.util.ArrayList;
public class Corretor
{
    private String nome;
    private int idade;
    private ArrayList<Imovel> carteira;
    
    public Corretor()
    {
        carteira = new ArrayList<>();
    }

    public int venderImovel()
    {
        return 0;
    }
    public double comissao(){
        return 0;
    }
    
}
