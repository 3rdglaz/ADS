public class Compra
{
    private Pessoa pessoa;
    private Produto produto;

    public Compra()
    {

    }

    public void comprar(Pessoa pessoa, Produto produto)
    {
        
    }
    public String verificarCompra(){
        return null;
    }
}
