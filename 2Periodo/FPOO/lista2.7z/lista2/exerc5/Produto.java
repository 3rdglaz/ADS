public class Produto
{
    private long codigo;
    private String nome;
    
    public Produto()
    {
                
    }
    
    public String consultaNome()
    {
        return nome;
    }
}
