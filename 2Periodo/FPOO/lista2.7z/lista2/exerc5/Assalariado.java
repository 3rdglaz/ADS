
public class Assalariado extends Empregado
{
    private double salario;

    public Assalariado()
    {

    }



}
