
public class Horista extends Empregado
{
    private double precoHora;
    private double horasTrabalhadas;

    public Horista()
    {

    }



}