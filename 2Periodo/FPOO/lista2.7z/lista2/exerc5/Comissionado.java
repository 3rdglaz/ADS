
public class Comissionado extends Empregado
{
    private double totalVenda;
    private double taxaComissao;

    public Comissionado()
    {

    }



}