
public class Main
{

    private int x;

    public Main()
    {
        
    }

    public int sampleMethod(int y)
    {
        return 0;
    }
}
