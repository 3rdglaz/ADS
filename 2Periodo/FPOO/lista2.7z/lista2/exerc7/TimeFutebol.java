
public class TimeFutebol
{
    private String nome;
    private String cidade;
    private String estado;
    private Jogador jogadores[] = new Jogador [11];
    public TimeFutebol()
    {
            
    }

        public int sampleMethod(int y)
    {
        return 0;
    }
    public String getNome(){return nome;}
    public void setNome(String nome){this.nome=nome;}
    
    public String getCidade(){return cidade;}
    public void setCidade(String cidade){this.cidade=cidade;}
    
    public String getEstado(){return estado;}
    public void setEstado(String estado){this.estado=estado;}
}
