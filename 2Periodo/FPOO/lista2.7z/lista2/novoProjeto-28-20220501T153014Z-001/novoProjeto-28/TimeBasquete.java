

public class TimeBasquete
{
    private int x;

    
    public TimeBasquete()
    {
        
    }

    
    public int sampleMethod(int y)
    {
        return x + y;
    }
}
