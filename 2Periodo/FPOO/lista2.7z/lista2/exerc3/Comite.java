
import java.util.ArrayList;
public class Comite
{
    private ArrayList <Artigo> artigos;
    private int x;
    public Comite()
    {
        artigos = new ArrayList<>();
    }


    public int sampleMethod(int y)
    {
        return 0;
    }
}
