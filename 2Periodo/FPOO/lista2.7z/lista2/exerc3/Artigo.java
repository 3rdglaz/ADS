public class Artigo
{
    private String titulo;
    private String resumo;
    private String autores; //array?
    
    public Artigo()
    {

    }


    public int sampleMethod(int y)
    {
        return 0;
    }
}
